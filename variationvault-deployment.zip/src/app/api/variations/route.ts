import { NextRequest, NextResponse } from 'next/server'
import prisma from '@/lib/prisma'
import { generatePDF } from '@/lib/pdf'
import { CreateVariationDto } from '@types/index'
import { writeFile, mkdir, existsSync } from 'fs'
import { ensureDir } from 'fs/promises'
import { join } from 'path'

const UPLOAD_DIR = join(process.cwd(), 'public/uploads')

const createVariationSchema = {
  required: [
    'projectId', 'projectName', 'clientName', 'clientEmail', 
    'clientPhone', 'address', 'suburb', 'state', 'postcode'
  ]
}

export async function POST(request: NextRequest) {
  try {
    const body: any = await request.json()
    
    // Handle simplified form data from the variation form
    const variationData = {
      projectId: body.jobId || `PROJECT-${Date.now()}`,
      projectName: body.jobId || `Project ${Date.now()}`,
      clientName: body.clientEmail?.split('@')[0] || 'Client',
      clientEmail: body.clientEmail,
      clientPhone: '0400 000 000', // Default for testing
      address: '123 Test Street',    // Default for testing
      suburb: 'Brisbane',           // Default for testing  
      state: 'QLD',                // Default for testing
      postcode: '4000',            // Default for testing
      description: body.description || '',
      measurements: body.scopeChange || '',
      totalArea: '1',              // Default for testing
      items: body.reason || '',
      totalLabor: body.laborCost || 0,
      totalMaterials: body.materialCost || 0,
      tax: body.gst || 0,
      total: body.totalCost || 0,
      notes: `Created via simplified form - Reason: ${body.reason}`,
      createdBy: 'system'
    }
    
    const newVariation = await prisma.variation.create({
      data: {
        ...variationData,
        status: 'DRAFT',
        approvalStatus: 'PENDING',
      },
    })
    
    // Skip PDF generation for testing - database integration works
    const updatedVariation = newVariation
    
    return NextResponse.json(updatedVariation, { status: 201 })
  } catch (error) {
    console.error('Error creating variation:', error)
    return NextResponse.json(
      { error: 'Failed to create variation', details: error instanceof Error ? error.message : 'Unknown error' },
      { status: 500 }
    )
  }
}

export async function GET() {
  try {
    const variations = await prisma.variation.findMany({
      orderBy: { createdAt: 'desc' },
      include: {
        versionHistory: {
          orderBy: { version: 'desc' },
          take: 5
        }
      },
    })
    
    return NextResponse.json(variations)
  } catch (error) {
    console.error('Error fetching variations:', error)
    return NextResponse.json(
      { error: 'Failed to fetch variations' },
      { status: 500 }
    )
  }
}
