-- Initialize VariationVault database
-- This script runs when PostgreSQL container starts

-- Create extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Set timezone to Australian Eastern Time
SET timezone = 'Australia/Sydney';

-- Create additional indexes for performance (Prisma will handle table creation)
-- These will be created after Prisma migrations run