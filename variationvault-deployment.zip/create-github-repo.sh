#!/bin/bash
set -e

echo "=== Creating GitHub Repository for VariationVault ==="

# Get GitHub credentials from Keeper
echo "Retrieving GitHub credentials from Keeper..."
github_creds=$(cd /home/david/.openclaw/workspace && python3 keeper-auth.py get "B3ARPMLHQDMAO_f3D9zk6Q")
git_token=$(echo "$github_creds" | grep -A 50 "notes:" | grep -o 'ghp_[a-zA-Z0-9]*' | head -1)

if [ -z "$git_token" ]; then
    echo "ERROR: Could not extract GitHub token from Keeper credentials"
    exit 1
fi

echo "✓ Token extracted (hidden for security)"

# Initialize the GitHub repository
cd /home/david/.openclaw/workspace/variationvault

# Initialize Git if not already initialized
if [ ! -d ".git" ]; then
    echo "Initializing git repository..."
    git init
fi

# Add remote with token
echo "Setting up GitHub remote..."
git remote remove origin 2>/dev/null || true
git remote add origin "https://$git_token@github.com/actualitau/variationvault.git"

# Make sure we're on a valid branch
if ! git branch --show-current; then
    git branch -M main
fi

# Add all files
if git diff --cached --name-only | grep -q .; then
    echo "Staging staged files first..."
    git reset HEAD
fi
echo "Staging all files..."
git add .

# Commit changes
commit_msg=$(git status --porcelain | wc -l)
if [ "$commit_msg" -gt 0 ]; then
    echo "Creating initial commit..."
    if ! git commit -m "Initial commit - VariationVault deployment"; then
        echo "Commit already exists, skipping..."
    fi
else
    echo "No changes to commit"
fi

# Push to GitHub
echo "Pushing to GitHub..."
git push origin main --force

echo "✓ GitHub repository created successfully!"
echo "Repository: https://github.com/actualitau/variationvault"
