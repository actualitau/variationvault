#!/bin/bash
# VariationVault Development Environment Setup

set -e

echo "🚀 Setting up VariationVault Development Environment..."

# Check if Docker is running
if ! docker info > /dev/null 2>&1; then
    echo "❌ Docker is not running. Please start Docker and try again."
    exit 1
fi

# Check if Docker Compose is available
if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose is not installed. Please install it and try again."
    exit 1
fi

# Create .env.local if it doesn't exist
if [ ! -f .env.local ]; then
    echo "📝 Creating .env.local from .env.example..."
    cp .env.example .env.local
    echo "✅ Created .env.local - you can customize it if needed"
fi

# Create necessary directories
echo "📁 Creating directories..."
mkdir -p public/uploads
mkdir -p logs

# Stop any existing containers
echo "🛑 Stopping existing containers..."
docker-compose down --remove-orphans

# Build and start services
echo "🏗️ Building and starting services..."
docker-compose up -d database minio mailhog adminer

# Wait for database to be ready
echo "⏳ Waiting for database to be ready..."
timeout=60
while ! docker-compose exec -T database pg_isready -U postgres > /dev/null 2>&1; do
    sleep 1
    timeout=$((timeout - 1))
    if [ $timeout -eq 0 ]; then
        echo "❌ Database failed to start within 60 seconds"
        exit 1
    fi
done

echo "✅ Database is ready!"

# Run database migrations
echo "📊 Running database migrations..."
docker-compose run --rm app npx prisma db push

# Create MinIO bucket
echo "📦 Setting up MinIO bucket..."
# Wait a bit for MinIO to be fully ready
sleep 5

# Install MinIO client
if ! command -v mc &> /dev/null; then
    echo "📥 Installing MinIO client..."
    curl -sSL https://dl.min.io/client/mc/release/linux-amd64/mc -o mc
    chmod +x mc
    sudo mv mc /usr/local/bin/
fi

# Configure MinIO client
mc alias set local http://localhost:9000 minioadmin minioadmin

# Create bucket
mc mb local/variationvault-uploads --ignore-existing

# Set bucket policy for public read access
mc policy set public local/variationvault-uploads

echo "✅ MinIO bucket configured!"

# Start the application
echo "🚀 Starting VariationVault application..."
docker-compose up -d app

# Wait for app to be ready
echo "⏳ Waiting for application to start..."
timeout=60
while ! curl -f http://localhost:3000/api/health > /dev/null 2>&1; do
    sleep 2
    timeout=$((timeout - 2))
    if [ $timeout -eq 0 ]; then
        echo "❌ Application failed to start within 60 seconds"
        echo "Check logs with: docker-compose logs app"
        exit 1
    fi
done

echo ""
echo "✅ VariationVault Development Environment is ready!"
echo ""
echo "🌐 Services:"
echo "   • Application:     http://localhost:3000"
echo "   • Database Admin:  http://localhost:8080"
echo "   • MinIO Console:   http://localhost:9001 (minioadmin/minioadmin)"
echo "   • Email Testing:   http://localhost:8025"
echo ""
echo "📊 Database:"
echo "   • Host: localhost:5432"
echo "   • Database: variationvault"
echo "   • User: postgres"
echo "   • Password: password"
echo ""
echo "🔧 Useful commands:"
echo "   • View logs:       docker-compose logs -f app"
echo "   • Stop services:   docker-compose down"
echo "   • Restart app:     docker-compose restart app"
echo "   • Database shell:  docker-compose exec database psql -U postgres -d variationvault"
echo ""
echo "🎯 Ready for development! Visit http://localhost:3000 to see VariationVault"