# VariationVault Development Guide

## 🚀 Quick Start

### Option 1: Docker Development Environment (Recommended)

Complete containerized environment with database, file storage, and email testing:

```bash
# Clone and setup
git clone https://github.com/actualitau/variationvault.git
cd variationvault

# Start development environment
chmod +x dev-setup.sh
./dev-setup.sh
```

**Services started:**
- **Application**: http://localhost:3000
- **Database Admin**: http://localhost:8080 (Adminer)
- **File Storage**: http://localhost:9001 (MinIO Console)
- **Email Testing**: http://localhost:8025 (MailHog)

### Option 2: Local Development

```bash
# Install dependencies
npm install

# Setup environment
cp .env.example .env.local

# Start local PostgreSQL (Docker)
docker run --name postgres -e POSTGRES_PASSWORD=password -d -p 5432:5432 postgres:15

# Run migrations
npx prisma db push

# Start development server
npm run dev
```

## 📱 Development Features

### Mobile-First Testing
- **Responsive Design**: Automatic mobile viewport optimization
- **Touch Targets**: 44px minimum for accessibility
- **PWA**: Installable app with offline support
- **Camera**: Mobile camera integration for photo capture

### Real-time Development
- **Hot Reload**: Automatic page refresh on code changes
- **Type Safety**: Full TypeScript integration
- **Database**: Live database updates with Prisma Studio
- **Email**: Catch all emails in MailHog interface

### Performance Targets
- **<60s** variation creation (mobile form)
- **<30s** client approval (mobile interface)
- **<15s** PDF export generation

## 🛠️ Development Stack

### Frontend
- **Next.js 14**: App Router with TypeScript
- **TailwindCSS**: Mobile-first responsive design
- **Progressive Web App**: Installable with offline support
- **React 18**: Server and client components

### Backend
- **Prisma**: Type-safe database ORM
- **PostgreSQL**: Primary database
- **AWS SDK**: S3 file uploads (MinIO locally)
- **PDF Generation**: jsPDF for exports

### Infrastructure
- **Docker**: Complete containerized development
- **MinIO**: Local S3-compatible storage
- **MailHog**: Email testing and debugging
- **Adminer**: Database administration interface

## 📋 Available Scripts

```bash
# Development
npm run dev              # Start development server
npm run build            # Build for production
npm run start            # Start production server
npm run lint             # Run ESLint
npm run type-check       # TypeScript checking

# Database
npm run db:generate      # Generate Prisma client
npm run db:push          # Push schema to database
npm run db:migrate       # Run database migrations
npm run db:studio        # Open Prisma Studio

# Docker
npm run docker:build     # Build Docker image
npm run docker:run       # Run Docker container
```

## 🧪 Testing the Application

### 1. Create a Variation

Visit http://localhost:3000 and:

1. Click "Create New Variation"
2. Fill in job details:
   - Job ID: `JOB-001`
   - Client Email: `test@example.com`
3. Add variation details:
   - Description: `Additional electrical work required`
   - Reason: `Client Request`
   - Scope Change: `Install 3 additional power outlets`
4. Take/upload photos
5. Set costs:
   - Material Cost: `$150`
   - Labor Cost: `$300`
6. Submit variation

### 2. Test Client Approval

1. Check MailHog at http://localhost:8025 for approval email
2. Click approval link in email
3. Test mobile approval interface
4. Submit approval/rejection

### 3. Test PDF Export

1. View variation details
2. Click "Export PDF"
3. Verify PDF includes photos, costs, and signatures

## 📊 Database Management

### Prisma Studio
```bash
npm run db:studio
```
- Visual database editor
- Real-time data viewing and editing
- Relationship visualization

### Adminer (Docker)
- URL: http://localhost:8080
- Server: `database`
- Username: `postgres`
- Password: `password`
- Database: `variationvault`

### Direct Database Access
```bash
# Via Docker Compose
docker-compose exec database psql -U postgres -d variationvault

# Via local PostgreSQL
psql postgresql://postgres:password@localhost:5432/variationvault
```

## 🔧 Configuration

### Environment Variables

Create `.env.local` with:

```env
# Database
DATABASE_URL="postgresql://postgres:password@localhost:5432/variationvault"

# File Storage (MinIO for development)
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=minioadmin
AWS_SECRET_ACCESS_KEY=minioadmin
AWS_S3_BUCKET=variationvault-uploads
S3_ENDPOINT=http://localhost:9000

# Authentication
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=dev-secret-key

# Email (MailHog for development)
EMAIL_FROM=dev@variationvault.local
SMTP_HOST=localhost
SMTP_PORT=1025
```

### Australian Configuration

Pre-configured for Australian market:
- **Currency**: AUD formatting
- **GST**: 10% calculation
- **Timezone**: Australia/Sydney
- **Business Terms**: Tradie-specific language

## 🐛 Debugging

### Application Logs
```bash
# Docker
docker-compose logs -f app

# Local
npm run dev  # Built-in logging
```

### Database Queries
Enable query logging in `.env.local`:
```env
DATABASE_URL="postgresql://postgres:password@localhost:5432/variationvault?schema=public&connection_limit=5&pool_timeout=20&logging=true"
```

### Network Issues
Check service connectivity:
```bash
# Test database
docker-compose exec app pg_isready -h database -p 5432

# Test MinIO
curl http://localhost:9000/minio/health/live

# Test application
curl http://localhost:3000/api/health
```

## 📱 Mobile Development

### Testing on Devices

1. **Local Network Access**:
   ```bash
   # Find your IP address
   ip addr show | grep 'inet 192.168'
   
   # Access from mobile device
   http://[YOUR-IP]:3000
   ```

2. **Chrome DevTools**:
   - F12 → Toggle Device Toolbar
   - Select mobile device preset
   - Test touch interactions

3. **PWA Installation**:
   - Chrome → Menu → Install App
   - Test offline functionality
   - Verify home screen icon

### Camera Testing

1. Enable HTTPS for camera access:
   ```bash
   # Generate self-signed certificate
   openssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365 -nodes
   ```

2. Or use Chrome flags:
   ```
   chrome://flags/#unsafely-treat-insecure-origin-as-secure
   Add: http://localhost:3000
   ```

## 🚀 Deployment Testing

### Local Production Build
```bash
# Build production version
npm run build

# Start production server
npm start

# Test at http://localhost:3000
```

### Docker Production Build
```bash
# Build production image
docker build -t variationvault .

# Run production container
docker run -p 3000:3000 --env-file .env.local variationvault
```

## 📞 Support

**Common Issues:**

1. **Port conflicts**: Change ports in `docker-compose.yml`
2. **Database connection**: Ensure PostgreSQL is running
3. **File uploads**: Check MinIO bucket permissions
4. **Build errors**: Clear `.next` folder and rebuild

**Getting Help:**
- Check GitHub Issues: https://github.com/actualitau/variationvault/issues
- Review logs: `docker-compose logs -f app`
- Database status: `docker-compose exec database pg_isready -U postgres`

---

**Happy coding!** 🎯 VariationVault Development Environment